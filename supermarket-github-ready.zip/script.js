const products=[
{name:"Apple",price:120,category:"Fruits",image:"images/apple.svg"},
{name:"Milk (1 L)",price:60,category:"Dairy",image:"images/milk.svg"},
{name:"Bread",price:40,category:"Snacks",image:"images/bread.svg"},
{name:"Vegetables",price:80,category:"Vegetables",image:"images/vegetables.svg"},
{name:"Chips",price:50,category:"Snacks",image:"images/snacks.svg"},
{name:"Cold Drink",price:50,category:"Drinks",image:"images/coke.svg"}
];

let cart=JSON.parse(localStorage.getItem("cart")||"[]");
let category="All";

const grid=document.getElementById("productGrid");
const search=document.getElementById("search");

function render(){
  const q=search.value.toLowerCase();
  const list=products.filter(p=>(category==="All"||p.category===category)&&p.name.toLowerCase().includes(q));
  grid.innerHTML=list.map((p,i)=>`
    <div class="card">
      <img src="${p.image}" alt="${p.name}">
      <h3>${p.name}</h3>
      <div class="price">₹${p.price}</div>
      <button onclick="addToCart(${products.indexOf(p)})">Add to Cart</button>
    </div>`).join("");
}
function addToCart(i){cart.push({...products[i],qty:1});save();showCart();}
function save(){localStorage.setItem("cart",JSON.stringify(cart));}
function showCart(){
  document.getElementById("cartCount").textContent=cart.reduce((s,p)=>s+p.qty,0);
  document.getElementById("cartItems").innerHTML=cart.length?cart.map((p,i)=>`
    <div class="cart-row">
      <span>${p.name}<br>₹${p.price}</span>
      <span class="qty">
        <button onclick="changeQty(${i},-1)">−</button>${p.qty}<button onclick="changeQty(${i},1)">+</button>
        <button onclick="removeItem(${i})">✕</button>
      </span>
    </div>`).join(""):"<p>Your cart is empty.</p>";
  document.getElementById("total").textContent=cart.reduce((s,p)=>s+p.price*p.qty,0);
}
function changeQty(i,n){cart[i].qty+=n;if(cart[i].qty<=0)cart.splice(i,1);save();showCart();}
function removeItem(i){cart.splice(i,1);save();showCart();}

document.querySelectorAll(".categories button").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".categories button").forEach(x=>x.classList.remove("active"));
  b.classList.add("active");category=b.dataset.category;render();
});
search.oninput=render;
document.getElementById("cartBtn").onclick=()=>document.getElementById("cart").scrollIntoView({behavior:"smooth"});
document.getElementById("checkout").onclick=()=>alert(cart.length?"Checkout demo — your cart is ready!":"Your cart is empty.");
render();showCart();
